from flask import Blueprint, render_template

main = Blueprint('main', __name__)

@main.route('/')
def index():
    return render_template('index.html')

@main.route('/market')
def market():
    return render_template('market.html')

@main.route('/diplom')
def diplom():
    return render_template('diplom.html')
