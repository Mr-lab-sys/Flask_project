from flask import Blueprint, request, jsonify
from flask_login import login_required, current_user
from .. import db
from ..models.models import UploadedFile
import os

api = Blueprint('api', __name__)

@api.route('/upload', methods=['POST'])
@login_required
def upload_file():
    if 'file' not in request.files:
        return jsonify({'error': 'Нет файла'}), 400
    file = request.files['file']
    if file.filename == '':
        return jsonify({'error': 'Пустое имя файла'}), 400

    filename = file.filename
    path = os.path.join('app/static/uploads', filename)
    file.save(path)

    new_file = UploadedFile(filename=filename, user_id=current_user.id)
    db.session.add(new_file)
    db.session.commit()

    return jsonify({'message': 'Файл загружен', 'filename': filename})
