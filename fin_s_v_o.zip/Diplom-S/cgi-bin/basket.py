import json
import sqlite3
import cgi
import html

params = cgi.FieldStorage()

goods = params.getfirst('goods','[1,2,3]')
goods = json.loads(goods)

connection = sqlite3.connect('data.db')
cursor = connection.cursor()

exp = str(-int(goods[0]))

for i in range(1, len(goods)):
    exp += ',' + str(-int(goods[i]))

cursor.execute('select * from goods where id in ({});'.format(exp))
x = cursor.fetchall()

connection.close()

html_table = '<table border="1px" width="300px">'
for i in x:
    html_table += '<tr>'
    for j in i:
        html_table += '<td>' + html.escape(str(j)) + '</td>'
    html_table += '</tr>'
html_table += '</table>'

print('Content-Type: text/html; charset=utf-8\n')

print(f'''
<!DOCTYPE html>
<html>
<head>
    <title>Корзина</title>
    <script>
    function pay(){{
        alert('Ваша оплата прошла успешно');
    }}
    </script>
</head>
<body>
<h1>Корзина</h1>
<h2>Ваш выбор:</h2>
{html_table}
<br>
<button onclick='pay()'>Оплатить</button>
</body>
</html>
''')