import sqlite3
from werkzeug.security import generate_password_hash

# Укажи здесь данные нового пользователя
username = 'admin'
password = 'admin123'

# Хешируем пароль
hashed_password = generate_password_hash(password)

# Подключение к базе данных
conn = sqlite3.connect('data.db')
cursor = conn.cursor()

try:
    cursor.execute("INSERT INTO users (username, password) VALUES (?, ?)", (username, hashed_password))
    conn.commit()
    print(f"Пользователь '{username}' добавлен.")
except sqlite3.IntegrityError:
    print(f"Пользователь '{username}' уже существует.")
finally:
    conn.close()
